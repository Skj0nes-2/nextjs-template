import "~/styles/globals.css";

import { type Metadata } from "next";
import { Comfortaa } from "next/font/google";

export const metadata: Metadata = {
  title: "New Project",
  description: "Next.JS website template.",
  icons: [{ rel: "icon", url: "/favicon.ico" }],
};

const comfortaa = Comfortaa({
  subsets: ["latin"],
});

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={comfortaa.className}>
      <body className="text-black dark:text-white bg-white dark:bg-black">{children}</body>
    </html>
  );
}
